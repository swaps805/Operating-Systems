#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

// uncomment to test
int arrGlobal[100000];

int main(){
    // int arrLocal[100000];
    // arrLocal[0] = 1;
    // printf("arrLocal: %d\n", arrLocal[0]);

    pgtPrint();
    exit(0);
}