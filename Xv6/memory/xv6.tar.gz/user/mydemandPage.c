#include "kernel/types.h" 
#include "user/user.h"
#include "kernel/fcntl.h"

#define N 5000 
int glob[N];

int
main(){
    // using dynamic memory allocation
    // int *arr = (int*)malloc(sizeof(int) * N);
    // arr[0] = 1;
    // printf("arr: %d\n", arr[0]);
    // pgtPrint();

    glob[0] = 2; 
    printf ("global addr from user space: %x\n", glob);

    for (int i=1;i<N;i++){
        glob[i] = glob[i-1];
        if (i%1000 ==0){
            pgtPrint();
            printf("\n");
        }
    }
    printf ("Printing final page table:\n");
    pgtPrint();
    
    printf("Value: %d\n", glob[N-1]);
    exit(0);
}