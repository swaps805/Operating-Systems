#include "kernel/types.h" 
#include "user/user.h"
#include "kernel/fcntl.h"

int main(){
    int arr[100000];
    arr[0] = 90;
    printf("arr: %d\n", arr[0]);

    uint64 bit_buff;
    
    // start_address = 0x0000
    // no. of pages to search for = 32
    // bit_buffer to store the result (paseed to kernel)
    
    pgaccess(0x0000, 32, &bit_buff);
    printf("bit_buff: %p\n", bit_buff);
    exit(0);
}