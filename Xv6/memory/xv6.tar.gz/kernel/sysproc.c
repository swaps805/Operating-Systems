#include "types.h"
#include "riscv.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "proc.h"

uint64
sys_exit(void)
{
  int n;
  argint(0, &n);
  exit(n);
  return 0;  // not reached
}

uint64
sys_getpid(void)
{
  return myproc()->pid;
}

uint64
sys_fork(void)
{
  return fork();
}

uint64
sys_wait(void)
{
  uint64 p;
  argaddr(0, &p);
  return wait(p);
}

uint64
sys_sbrk(void)
{
  uint64 addr;
  int n;

  argint(0, &n);
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

uint64
sys_sleep(void)
{
  int n;
  uint ticks0;

  argint(0, &n);
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

uint64
sys_kill(void)
{
  int pid;

  argint(0, &pid);
  return kill(pid);
}

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

//---------------------------------------------------
// to construct the virtual address
static uint64 lvl0 = 0;
static uint64 lvl1 = 0;
static uint64 lvl2 = 0;

// helper function
void
PT_print(pagetable_t pagetable, int level){
  // traverse the PTEs
  for(int i = 0; i < 512; i++) {
    pte_t pte = pagetable[i];
    uint64 va = 0;
    if (level == 0){
      // outer most page directory address 30-38
      lvl0 = i << 30;
      va = lvl0;
    } 
    else if (level == 1) {
      // second level page directory address 21-29
      lvl1 = i << 21;
      va = lvl0 + lvl1;
    } 
    else if(level == 2) {
      // third level page directory address 12-20 
      lvl2 = i << 12;
      va = lvl0 + lvl1 + lvl2;
    }
    // if PTE is valid and can be accessed by user then its a PTE 
    // and is mapped to a physical address
    if ((pte & PTE_V)&& (pte & PTE_U)){
        printf("PTE entry %d: virtual address %p physical address %p \n", i, va, PTE2PA(pte));
    }
    // inner level page table and points to lower level
    if ((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0) {
        uint64 child = PTE2PA(pte);
        PT_print((pagetable_t)child, level+1);
    }
  }
}

uint64
sys_pgtPrint(void){
  // obtain page table of current process
  pagetable_t pgtbl = myproc()->pagetable;
  PT_print(pgtbl, 0);

  return 0;
}

//------------------------------------------------------
uint64
sys_pgaccess(void){
  // get the starting address, number of pages and buffer address
  uint64 st_addr;
  int n;
  uint64 bit_buff;

  // fetches the 1,2,3 argument of the system call invoked in used function
  argaddr(0, &st_addr);
  argint(1, &n);
  argaddr(2, &bit_buff);

  // store mask
  uint64 mask = 0;
  pagetable_t pgtbl = myproc()->pagetable;
  for (int i = 0; i < n; i++) {
    // traverse the PTEs from  start address to find a given va
    uint64 add_range = st_addr + i*PGSIZE;
    pte_t *pte = walk(pgtbl, add_range, 0);
    //if PTE is accessed then its modified

    if (*pte & PTE_A) {
      // store the value in the bitmask for the ith page
      mask = mask |(1 << i); 
      // clear the accessed bit
      *pte = *pte & (~PTE_A);

      if (*pte & PTE_D) {
        mask = mask |(1 << (i+n)); 
        *pte = *pte & (~PTE_D);
      }
    }
  }
  // copy the mask to the buffer and return to user function
  copyout(pgtbl, bit_buff, (char *)&bit_buff, sizeof(bit_buff));
  return 0;
}
